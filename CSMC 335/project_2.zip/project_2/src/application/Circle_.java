/*
 * Created By: Antonio Scalfaro
 * CMSC 335
 * Project 2 - Shapes GUI
 * 
 * This is the Circle_ class that extends the javaFX Circle class. It has a constructor that calls the 
 * Circle constructor.
 * */

package application;

import javafx.scene.shape.*;
public class Circle_  extends Circle{
	
	public Circle_(double radius) {
		super(radius);
	}
	
}
